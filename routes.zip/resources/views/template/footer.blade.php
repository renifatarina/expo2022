<footer>

    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 px-5">
                    <h5 class="text pb-2">Supported by</h5>
                    <img class="img" src="{{asset('/assets/images/new/amikom.png')}}" alt="">
                </div>
                <div class="col-lg-6 contact">
                    <h5 class="pb-2">Contact</h5>
                    <ul class="flex-container">
                        <li><a href="https://www.instagram.com/expoamikom22/?hl=en" >
                            <i class="fa-brands fa-square-instagram fa-3x"></i>
                        </a></li>
                        <li><a href="mailto:humas.expoamikom@gmail.com">
                            <i class="fa-solid fa-square-envelope fa-3x px-3"></i>
                        </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>Copyright © 2022 EXPO AMIKOM 2022. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>

</footer>
