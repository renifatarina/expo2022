@extends('template.base')

@section('content')
<div class="master bso">
    @yield('custom')
    
</div>

@endsection
