@extends('template.base')

@section('content')
<div class="master detail">
    @yield('custom')
    
</div>

@endsection
