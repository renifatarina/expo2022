@extends('template.base')

@section('content')
<div class="master">
    @yield('custom')
    
</div>

@endsection
