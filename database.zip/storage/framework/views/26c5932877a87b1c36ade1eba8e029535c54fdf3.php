<?php $__env->startSection('custom'); ?>
<div class="container">
    <h4 class="text-center pb-3">HIMPUNAN</h4>
    <div class="row">
        <div class="col-lg-1 col-sm-6">
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-1 col-sm-6">
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-1 col-sm-6">
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
        <div class="col-lg-2 col-sm-6">
            <div class="item">
                <img src="assets/images/popular-02.jpg" alt="">
                <div class="text-center">
                    <h4 >PubG</h4>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\expo\reni fix\expo\resources\views/orma.blade.php ENDPATH**/ ?>