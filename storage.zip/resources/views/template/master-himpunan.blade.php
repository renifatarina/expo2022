@extends('template.base')

@section('content')
<div class="master himpunan">
    @yield('custom')
    
</div>

@endsection
