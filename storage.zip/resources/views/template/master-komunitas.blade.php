@extends('template.base')

@section('content')
<div class="master komunitas">
    @yield('custom')
    
</div>

@endsection
