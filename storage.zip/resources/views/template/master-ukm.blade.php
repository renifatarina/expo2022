@extends('template.base')

@section('content')
<div class="master ukm">
    @yield('custom')
    
</div>

@endsection
