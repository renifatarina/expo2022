<?php $__env->startSection('title'); ?>
    List UKM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?> 
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="/admin/add-ukm" class="btn btn-primary mb-3">Add New UKM</a>
    <table class="table">
        <thead class="thead-light">
            <tr>
            <th scope="col">#</th>
            <th scope="col" width="150px">Title</th>
            <th scope="col"width="150px">Description</th>
            <th scope="col"width="150px">Picture</th>
            <th scope="col"width="150px">Basement</th>
            <th scope="col"width="150px">Location</th>
            <th scope="col">Date Created</th>
            <th scope="col" >Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $ukms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ukm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></th>
                    <td><?php echo e($ukm->title); ?></td>
                    <td><?php echo e(Str::limit($ukm->desc, 60)); ?></td>
                    <td><?php echo e($ukm->picture); ?></td>
                    <td><?php echo e($ukm->basement); ?></td>
                    <td><?php echo e($ukm->loc); ?></td>
                    <td><?php echo e($ukm->created_at); ?></td>
                    <td>
                        <form action="/admin/ukm/<?php echo e($ukm->id); ?>" method="POST">
                            <a href="/admin/ukm/<?php echo e($ukm->id); ?>" class="btn btn-info">Edit</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" class="btn btn-danger my-1" onclick="return confirm('Are you sure?')" value="Delete">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr colspan="3">
                    <td class="text-center">No data</td>
                </tr>  
            <?php endif; ?>              
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\expo\reni fix\expo\resources\views/admin/ukm/list.blade.php ENDPATH**/ ?>