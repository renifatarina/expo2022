<?php $__env->startSection('title'); ?>
    List BSO
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?> 
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="/admin/add-bso" class="btn btn-primary mb-3">Add New BSO</a>
    <table class="table">
        <thead class="thead-light">
            <tr>
            <th scope="col">#</th>
            <th scope="col" width="150px">Title</th>
            <th scope="col"width="150px">Description</th>
            <th scope="col"width="150px">Picture</th>
            <th scope="col"width="150px">Basement</th>
            <th scope="col"width="150px">Location</th>
            <th scope="col">Date Created</th>
            <th scope="col" >Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $bsos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$bso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></th>
                    <td><?php echo e($bso->title); ?></td>
                    <td><?php echo e(Str::limit($bso->desc, 60)); ?></td>
                    <td><?php echo e($bso->picture); ?></td>
                    <td><?php echo e($bso->basement); ?></td>
                    <td><?php echo e($bso->loc); ?></td>
                    <td><?php echo e($bso->created_at); ?></td>
                    <td>
                        <form action="/admin/bso/<?php echo e($bso->id); ?>" method="POST">
                            <a href="/admin/bso/<?php echo e($bso->id); ?>" class="btn btn-info">Edit</a>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" class="btn btn-danger my-1" onclick="return confirm('Are you sure?')" value="Delete">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr colspan="3">
                    <td class="text-center">No data</td>
                </tr>  
            <?php endif; ?>              
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\expo\reni fix\expo\resources\views/admin/bso/list.blade.php ENDPATH**/ ?>