<?php $__env->startSection('content'); ?>
<div class="master bso">
    <?php echo $__env->yieldContent('custom'); ?>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\expo\reni fix\expo\resources\views/template/master-bso.blade.php ENDPATH**/ ?>