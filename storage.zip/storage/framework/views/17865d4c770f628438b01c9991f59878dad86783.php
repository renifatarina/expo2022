<?php $__env->startSection('custom'); ?>
<div class="container">
    <div class="back">
        <a href="/himpunan" class="d-flex justify-content-start"><i class="fa-solid fa-caret-left fa-3x"></i> <p>Back</p></a>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="image text-center">
                <img src="<?php echo e(asset('img-upload/'.$himpunan->picture)); ?>" alt="" width="">
            </div>
            <div class="row">
                <div class="col-md-7 loc1">
                    <h5 class="text-center">Basement <?php echo e($himpunan->basement); ?></h5>
                </div>
                <div class="col-md-4 loc2">
                    <h5 class="text-center">No <?php echo e($himpunan->loc); ?></h5>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <h4 class="title"><?php echo e($himpunan->title); ?></h4>
            <p class="desc"><?php echo e($himpunan->desc); ?></p>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\expo\reni fix\expo\resources\views/detail-himpunan.blade.php ENDPATH**/ ?>