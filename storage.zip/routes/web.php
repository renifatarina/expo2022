<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', function () {
    return view('home');
});

Route::get('/himpunan', function () {
    return view('himpunan');
});
Route::get('/bso', function () {
    return view('bso');
});

Route::get('/komunitas', function () {
    return view('komunitas');
});

Route::get('/faq', function () {
    return view('faq');
});

Route::get('/detail', function () {
    return view('detail');
});

Route::get('/admin', function () {
    return view('admin.master');
});

// UKM
Route::get('/ukm', 'UkmController@show');
Route::get('/admin/add-ukm', 'UkmController@create');
Route::post('/admin/list-ukm', 'UkmController@store');
Route::get('/admin/list-ukm', 'UkmController@index');
Route::get('/admin/ukm/{ukm_id}', 'UkmController@edit');
Route::put('/admin/ukm/{ukm_id}', 'UkmController@update');
Route::delete('/admin/ukm/{ukm_id}', 'UkmController@destroy');
Route::get('/ukm/{ukm_id}', 'UkmController@upload');

// BSO
Route::get('/bso', 'BsoController@show');
Route::get('/admin/add-bso', 'BsoController@create');
Route::post('/admin/list-bso', 'BsoController@store');
Route::get('/admin/list-bso', 'BsoController@index');
Route::get('/admin/bso/{bso_id}', 'BsoController@edit');
Route::put('/admin/bso/{bso_id}', 'BsoController@update');
Route::delete('/admin/bso/{bso_id}', 'BsoController@destroy');
Route::get('/bso/{bso_id}', 'BsoController@upload');

// Himpunan
Route::get('/himpunan', 'HimpunanController@show');
Route::get('/admin/add-himpunan', 'HimpunanController@create');
Route::post('/admin/list-himpunan', 'HimpunanController@store');
Route::get('/admin/list-himpunan', 'HimpunanController@index');
Route::get('/admin/himpunan/{himpunan_id}', 'HimpunanController@edit');
Route::put('/admin/himpunan/{himpunan_id}', 'HimpunanController@update');
Route::delete('/admin/himpunan/{himpunan_id}', 'HimpunanController@destroy');
Route::get('/himpunan/{himpunan_id}', 'HimpunanController@upload');

// Komunitas
Route::get('/komunitas', 'KomunitasController@show');
Route::get('/admin/add-komunitas', 'KomunitasController@create');
Route::post('/admin/list-komunitas', 'KomunitasController@store');
Route::get('/admin/list-komunitas', 'KomunitasController@index');
Route::get('/admin/komunitas/{komunitas_id}', 'KomunitasController@edit');
Route::put('/admin/komunitas/{komunitas_id}', 'KomunitasController@update');
Route::delete('/admin/komunitas/{komunitas_id}', 'KomunitasController@destroy');
Route::get('/komunitas/{komunitas_id}', 'KomunitasController@upload');